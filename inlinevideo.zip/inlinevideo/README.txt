A Pen created at CodePen.io. You can find this one at http://codepen.io/newshorts/pen/yNxNKR.

 for iphones

the github project is here:

https://github.com/newshorts/InlineVideo